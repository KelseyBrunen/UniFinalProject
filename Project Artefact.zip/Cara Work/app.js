const chatBody = document.querySelector(".chat-body");
const txtInput = document.querySelector("#txtInput");
const send = document.querySelector(".send");
let messageCounter = 0;
const spacingReductionPercentage = 0.2;

send.addEventListener("click", () => renderUserMessage());

txtInput.addEventListener("keyup", (event) => {
  if (event.keyCode === 13) {
    renderUserMessage();
  }
});

const renderUserMessage = () => {
  const userInput = txtInput.value.toLowerCase(); // Convert user input to lowercase
  renderMessageEle(userInput, "user");
  txtInput.value = "";
  setTimeout(() => {
    renderChatbotResponse(userInput);
    setScrollPosition();
    checkMessageCount();
  }, 600);
};

const renderChatbotResponse = (userInput) => {
  const res = getChatbotResponse(userInput);
  renderMessageEle(res, "chatbot"); // Pass "chatbot" as the type parameter
};

const renderMessageEle = (txt, type) => {
  let className = "user-message";
  if (type === "chatbot") { // Check for "chatbot" type
    className = "chatbot-message";
  }
  const messageEle = document.createElement("div");
  const txtNode = document.createTextNode(txt);
  messageEle.classList.add(className);
  messageEle.append(txtNode);
  chatBody.append(messageEle);
  messageCounter++;
};

const getChatbotResponse = (userInput) => {
  // Iterate over each keyword in the responseObj
  for (const keyword in responseObj) {
    // Check if the user input contains the keyword
    if (userInput.includes(keyword)) {
      return responseObj[keyword];
    }
  }
  
  // Return a default response if no keyword is found
  return "Please try something else";
};

const setScrollPosition = () => {
  if (chatBody.scrollHeight > 0) {
    chatBody.scrollTop = chatBody.scrollHeight;
  }
};

const checkMessageCount = () => {
  if (messageCounter >= 3) {
    const messages = chatBody.querySelectorAll(".user-message, .chatbot-message");
    chatBody.removeChild(messages[0]); // Remove the oldest message
    messageCounter--;

    // Update the position of the remaining messages with reduced spacing
    const messageElements = chatBody.querySelectorAll(".user-message, .chatbot-message");
    let marginTop = 0;
    messageElements.forEach((message) => {
      message.style.marginTop = `${marginTop}px`;
      marginTop = Math.floor(message.offsetHeight * spacingReductionPercentage);
    });
  }
};
